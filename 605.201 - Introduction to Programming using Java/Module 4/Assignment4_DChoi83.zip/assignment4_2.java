/**
 * Module 4 Assignment 2
 *
 * Print Calendar using Zeller's Algorithm
 * Displays full calendar for inputted year
 *
 * @author: Daniel Choi
 * Date created: 30 September 2018
 **/
import java.util.Scanner;

public class assignment4_2
{

    /** Main method **/
    public static void main(String[] args)
    {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter full year (e.g., 2012): ");             //Prompts user to enter desired year in 4-digit format
        int year = input.nextInt();
        int math;

        printMonthCalendar(year,1);                             //Displays calendar for January
        System.out.println();
        printMonthCalendar(year,2);                             //Displays calendar for February
        System.out.println();
        printMonthCalendar(year,3);                             //Displays calendar for March
        System.out.println();
        printMonthCalendar(year,4);                             //Displays calendar for April
        System.out.println();
        printMonthCalendar(year,5);                             //Displays calendar for May
        System.out.println();
        printMonthCalendar(year,6);                             //Displays calendar for June
        System.out.println();
        printMonthCalendar(year,7);                             //Displays calendar for July
        System.out.println();
        printMonthCalendar(year,8);                             //Displays calendar for August
        System.out.println();
        printMonthCalendar(year,9);                             //Displays calendar for September
        System.out.println();
        printMonthCalendar(year,10);                            //Displays calendar for October
        System.out.println();
        printMonthCalendar(year,11);                            //Displays calendar for November
        System.out.println();
        printMonthCalendar(year,12);                            //Displays calendar for December
        System.out.println();
    }

    /** Print the calendar for a month in a year **/
    public static void printMonthCalendar(int year, int month)
    {
        printMonthHeader(year, month);                                  //Print Heading for Month Calendar
        printMonthBody(year, month);                                    //Print Body of Month Calendar
    }

    /** Print the month title, e.g., October 2012 **/
    public static void printMonthHeader(int year, int month)
    {
        System.out.println("         " + getMonthName(month) + " " + year); //Prints Month Name                                         //Prints Month Name (e.g. 10 = October)
        System.out.println("-----------------------------");            //Prints spacing line
        System.out.println(" Sun Mon Tue Wed Thu Fri Sat");             //Prints 3-character days of the week
    }
    /** Print out the body of the month **/
    public static void printMonthBody(int year, int month)
    {
        int firstDay = getStartDay(year, month, 1);                //Obtains start day of the week for the first date in the month
        int NumDaysInMonth = getNumDaysInMonth(year, month);            //Obtains the number of days in the month

        // Creates spaces depending on the placement of the first day //
        int h;                                                          //h = Day number o first day in month 'm'
        for (h = 0; h < firstDay; h++)
            System.out.print("    ");                                   //Prints out # spaces for first day of the month

        for (h = 1; h <= NumDaysInMonth; h++)
        {
            System.out.printf("%4d", h);                                //Format and align output to 4 digits depending on h

            if ((firstDay + h) % 7== 0)
                System.out.println();                                   //If % 0 then no need to adjust and print normally
        }

        System.out.println();
    }

    /** Return the appropriate month name for the number entered  **/
    public static String getMonthName(int month)
    {
        String MonthName = "";                                          //Utilize switch between cases for month names
        switch (month)
        {
            case 1: MonthName = "January";
                break;
            case 2: MonthName = "February";
                break;
            case 3: MonthName = "March";
                break;
            case 4: MonthName = "April";
                break;
            case 5: MonthName = "May";
                break;
            case 6: MonthName = "June";
                break;
            case 7: MonthName = "July";
                break;
            case 8: MonthName = "August";
                break;
            case 9: MonthName = "September";
                break;
            case 10: MonthName = "October";
                break;
            case 11: MonthName = "November";
                break;
            case 12: MonthName = "December";
        }
        return MonthName;
    }

    /** Get the start day for the entered month and year **/
    public static int getStartDay(int year, int month, int day)
    {
        if (month == 1)
        {
            month = 13;
            year--;
        }
        else if (month == 2)
        {
            month = 14;
            year--;
        }
        int k = year%100;   //Calculate year within century; k = yearInCent
        int j = year/100;   //Calculate century term; j = century

        return ((day + (13 * (month + 1) / 5) + k + (k / 4) + (j / 4) + (5 * j)) % 7 -1);    //Return day number
    }

    /** Get the number of days in a month **/
    public static int getNumDaysInMonth(int year, int month)
    {
        if (month == 1 || month == 3 || month == 5 || month == 7 || month == 8 || month == 10 || month == 12)
            return 31;                                                  //For all months with 31 days
        if (month == 4 || month == 6 || month == 9 || month == 11)
            return 30;                                                  //For all months with 30 days
        if (month == 2)
            return isLeapYear(year) ? 29 : 28;                          //Use ternary ? for dedicated leap year in February
        return 0;                                                       //When month # out of range return 0
    }

    /** Determine if year entered is a leap year **/
    public static boolean isLeapYear(int year)
    {
        return (year % 4 == 0 && year % 100 != 0) || year % 400 == 0 ;   //Determine if year is leap year
    }
}
/* 
Assignment 1 - Daniel Choi 
Displays the output "My Java Using Terminal" in the same manner as indicated in the assignment but replacing TERMINAL with JGRASP
*/ 

public class Assignment1 
{
   public static void main(String [] args)
   {
      System.out.println();//inserts 1 newline
      System.out.println("MM   MM Y    Y       J     A    V     V    A");
      System.out.println("M MMM M  Y  Y        J    A A    V   V    A A");
      System.out.println("M  M  M    Y     J   J   AAAAA    V V    AAAAA");
      System.out.println("M     M    Y      J J   A     A    V    A     A");
      System.out.println();//inserts 1 newline
      System.out.println();//inserts 1 newline
      System.out.println("U     U SSSSS   IIIIIII N     N  GGGG");
      System.out.println("U     U S          I    NN    N  G");
      System.out.println("U     U  SS        I    N N   N  G GGGG");
      System.out.println(" U   U      S      I    N  N  N  G    G");
      System.out.println("  UUU    SSSS    IIIII  N    NN  GGGGGG");
      System.out.println();//inserts 1 newline
      System.out.println();//inserts 1 newline
      System.out.println("    J  GGGG   RRRRR     A     SSSSS PPPPP");
      System.out.println("    J  G      R   R    A A    S     P   P");
      System.out.println("    J  G GGGG RRRR    AAAAA    SS   PPPPP");
      System.out.println("J   J  G    G R R    A     A      S P");
      System.out.println(" JJJ   GGGGGG R  RR A       A SSSS  p");
      System.out.println();//inserts 1 newline
      System.out.println();//inserts 1 newline
   }
}
/**
 * This class represents an English Spaniel dog.
 **/
public class EnglishSpaniel extends Dog
{
    /**
     * Displays on standard out the type of dog this class represents.
     **/
    public void display()
    {
        System.out.println("English Spaniel");
    }

    /**
     * Displays on standard out a barking
     **/
    public void bark()
    {
        System.out.println("English Spaniel BARK!");
    }
}

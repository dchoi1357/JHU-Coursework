/**
 * This class represents an Chihauhua dog.
 **/
public class Chihuahua extends Dog
{
    /**
     * Displays on standard out the type of dog this class represents.
     **/
    public void display()
    {
        System.out.println("Chihuahua");
    }

    /**
     * Displays on standard out a barking
     **/
    public void bark()
    {
        System.out.println("ChihuahuaBARK!");
    }
}

/**
 * This program displays type and barks of various doges.
 **/
public class Dogs
{
    public static void main(String[] args)
    {
        EnglishSpaniel teaDog   = new EnglishSpaniel();;
        Chihuahua      crazyDog = new Chihuahua();
        FrenchPoodle   wineDog  = new FrenchPoodle();
    
        teaDog.display();
        teaDog.bark();
        crazyDog.display();
        crazyDog.bark();
        wineDog.display();
        wineDog.bark();
    }
}

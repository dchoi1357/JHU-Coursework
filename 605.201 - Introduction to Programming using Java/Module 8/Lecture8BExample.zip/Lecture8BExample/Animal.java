/**
 * This class represents an abstract animal.
 **/
public abstract class Animal
{
    public abstract void display();
}

/**
 * This class represents an French Poodledog.
 **/
public class FrenchPoodle extends Dog
{
    /**
     * Displays on standard out the type of dog this class represents.
     **/
    public void display()
    {
        System.out.println("French Poodle");
    }

    /**
     * Displays on standard out a barking
     **/
    public void bark()
    {
        System.out.println("French Poodle BARK!");
    }
}

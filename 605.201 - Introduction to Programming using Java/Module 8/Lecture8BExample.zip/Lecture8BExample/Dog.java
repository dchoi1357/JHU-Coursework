/**
 * This class defines an abstract dog.
 **/
public abstract class Dog extends Animal
{
    public abstract void bark();
}

//Universal Class for all Interfaces
public abstract class All implements Drawable, Resizeable, Rotatable, Sounds
{

}
public interface Resizeable
{
    void resizeObject();
}
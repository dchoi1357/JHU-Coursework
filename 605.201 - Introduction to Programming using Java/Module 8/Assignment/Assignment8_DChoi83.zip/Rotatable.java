public interface Rotatable
{
    void rotateObject();
}
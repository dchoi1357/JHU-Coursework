public interface Drawable
{
    void drawObjects();
}
public interface Sounds
{
    void playSound();
}
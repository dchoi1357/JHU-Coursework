/* 
Assignment 3, Part 1 - Daniel Choi 
Program that displays sequence of plus signs in decrementing manner by line when prompted to enter maximum number of signs
*/ 

import java.util.Scanner;

public class Assignment3_1 
{
   public static void main(String [] args)
   {
   		// Define and initialize variables for maximum # of + signs to display and choice 1 or 2
   		int max = 0;		// Maximum value of + signs to be displayed
   		int choice = 0;    	// Choice value of either 1 or 2 to be chosen 
   		int a,b;			// Values used for for loops
   		
   		// Use a Scanner to input integer values
   		Scanner input = new Scanner(System.in);
   		System.out.println( "\n\n" );
   		System.out.print ( "Enter the maximum number of + signs to be displayed: " );
   		max = input.nextInt();		//Input maximum number of + signs to be displayed
   		System.out.print ( "Enter the Choice of display: 1 for Maximum output first, 2 for Maximum output last: ");
   		choice = input.nextInt(); 	//Input choice of display
   		
   		//Display Output depending on values entered
   		if (choice==1)
   		{ //Path if Choice 1 is selected 
   			for (a=max; a>=1; --a)
   			{
   				for(b=1; b<=a; ++b)
   				{
   					System.out.print("+");
   				}
   				System.out.println();
   			}
   		}
   		else
   		{ //Path is Choice 2 is selected
   			for (a=1; a<=max; ++a)
   			{
   				for(b=1;b<=a;++b)
   				{
   					System.out.print("+");
   				}
   				System.out.println();
   			}
   		} 
   }
}
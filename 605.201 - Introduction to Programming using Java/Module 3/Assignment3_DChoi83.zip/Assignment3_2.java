 /* 
Assignment 3, Part 2 - Daniel Choi 
Guess a Secret Number 
*/ 

import java.util.Scanner;
import java.lang.Math;

public class Assignment3_2 
{
   public static void main(String [] args)
   {	
   
   // Define and initialize applicable variables
   		int N=0;					// Maximum value for the random number generator 
   		int attemptcount=0; 	// Count for number of guesses 
   		int randomNumber;		// Random number that is generated 
   		int maxattempt=0;		// Maximum # of attempts at the game 
   		int guess; 				// Guessing variable for the game
   		int win=0;				// Correct guess count
         int play=1;	         // Play again 

        
    // Welcome Message
        System.out.println ("Welcome to the Number Guessing Program");
        
   while (play==1)
   {
   
    // Use a Scanner to input integer values
   	  Scanner input = new Scanner(System.in);
   	  System.out.println( "\n" );
   	  System.out.print ("Enter the maximum possible value for the guessing game: " );
   	  N = input.nextInt();				   //Input maximum possible value for the game
   	  System.out.print ("Enter the maximum number of attempts at the game: " );
   	  maxattempt = input.nextInt();		//Input maximum possible attempts for the game
        
   // Random Number Generator         
      randomNumber = (int) ( N * Math.random() +1 );
   	System.out.println("Enter a number between 1 and "+N+".");
   	
         while (attemptcount < maxattempt && win!=1)
         {
         
           System.out.print("Enter your guess: ");
   		   guess = input.nextInt();
   		
   		   if (guess==randomNumber)
   		   	{
               System.out.println("Your guess correctly matched the random number!");
   		      win++;
               attemptcount++;
               System.out.println("You guessed the correct answer in "+attemptcount+" tries!");
   		   	}
   		   else if (guess>randomNumber)
   		      {
   		      System.out.println("Your guess is too high!");
   		      attemptcount++;
   		      }
   		   else if (guess<randomNumber)
   		      {
   		      System.out.println("Your guess is too low!");
   		      attemptcount++;
               }
         }
     System.out.println( "Game Over" );   
     System.out.println("Would you like to play again? 1 for Yes, 0 for No");
     play = input.nextInt();		//Input response for play again
     attemptcount=0;
     win=0;    
   }
   System.out.println( "Goodbye!" ); 
   
   
}  	

}